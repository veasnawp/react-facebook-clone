import avatar from "./user-avatar.jpg";
import facebookPngOne from "./user-avatar.jpg";
import { IconsComponent } from "./icons/facebook-svg";

export { avatar, facebookPngOne, IconsComponent };
