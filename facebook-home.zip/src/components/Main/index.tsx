import MainFeed from './mainFeed'
import { LeftSidebar } from './left-sidebar'
import { RightSidebar } from './right-sidebar'

export const Main = () => {
  return (
    <div id="main" className='default_container box-border relative'>
      <div className='relative-flex-col'>
        <div className='relative-flex-col top-[var(--header-height)] min-h-[calc(100vh-var(--header-height))]'>
        <div className='relative-flex-col'>
          <div className='relative-flex-row box-border shrink-0 items-stretch'>
            <div className='relative-flex-row box-border shrink items-start justify-between min-w-0'>
              <LeftSidebar />
              <MainFeed />
              <RightSidebar />
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  )
}
