import avatar from "../../assets/user-avatar.jpg"


export default function MainFeed() {

  return (
    <div id="main-feed" className='relative-flex-row box-border shrink items-stretch flex-nowrap basis-[744px] justify-center min-w-0 px-8'>
      <div className='relative-flex-col box-border shrink-0 min-w-0 max-w-full'>
        <div className='relative box-border'>
          <div className='w-full my-4'>
            <StoryBoard />
            <CreateNewPostSection />
          </div>
        </div>
      </div>
    </div>
  )
}

function StoryBoard() {
  return (
    <div className='min-h-[250px]'>
      <div className="flex space-x-2 mx-auto max-w-2xl relative mb-4">
        <div className="w-[140px] h-[250px] rounded-xl overflow-hidden flex flex-col group cursor-pointer relative box-shadow shadow shadow-[var(--shadow-base)]">
            <img className="w-full h-4/5 object-cover transition duration-300 ease-in-out transform group-hover:scale-105" src={avatar} alt="Veasna Meta"/>
            <div className="bg-white relative flex-1 flex flex-col">
                <div className="bg-[#0866FF] p-0.5 rounded-full border-4 border-white absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                </div>
                <div className="flex-1 pb-1 text-white text-sm font-semibold capitalize flex justify-center items-end">
                    <p> Create Story </p>
                </div>
            </div>

            <div className="absolute inset-0 bg-black opacity-0 transition duration-300 ease-in-out group-hover:opacity-20"></div>
        </div>

        {
          [...Array(3).keys()].map((item) => {

            return (
              <div key={item} className="w-[140px] h-[250px] rounded-xl overflow-hidden flex flex-col relative group cursor-pointer box-shadow shadow shadow-[var(--shadow-base)]">
                  <img className="w-full h-full object-cover transition duration-300 ease-in-out transform group-hover:scale-105" src="https://picsum.photos/200/300?random=1" alt="thumbnail user's story"/>

                  <div className="w-8 h-8 border-4 box-content border-[#0866FF] rounded-full overflow-hidden absolute left-2.5 top-3">
                      <img className="w-full h-full object-cover" src={avatar} alt="Veasna Meta"/>
                  </div>

                  <div className="absolute inset-x-3 bottom-1">
                      <p className="text-white font-semibold">Your Story</p>
                  </div>

                  <div className="absolute inset-0 bg-black opacity-0 transition duration-300 ease-in-out group-hover:opacity-20"></div>
              </div>
            )
          })
        }


        <div className="absolute bg-white hover:bg-[var(--web-bg-color)] gray-600 transition-colors ease-in-out duration-200 p-2 rounded-full right-0 top-1/2 transform -translate-y-1/2 translate-x-1/2 cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
        </div>
      </div>
    </div>
  )
}

function CreateNewPostSection() {

  return (
    <div className="mb-4">
      <div className="relative-flex-col">
        <div className="bg-white box-shadow shadow-[var(--shadow-base)] h-[50px]"></div>
      </div>
    </div>
  )
}